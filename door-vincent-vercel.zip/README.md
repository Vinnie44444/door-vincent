# Door Vincent website

## Deployen op Vercel
1. Log in op Vercel
2. Add New > Project
3. Upload deze zip of importeer via Git
4. Klik Deploy
5. Voeg daarna je domein `door-vincent.nl` toe bij Domains

## DNS bij TransIP
Gebruik de records die Vercel toont.
Voor `www` gebruik je doorgaans:
- Type: CNAME
- Name: www
- Value: cname.vercel-dns.com
